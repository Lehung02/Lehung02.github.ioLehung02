<template>
   <h1>OKE</h1>
</template>

<script>
export default {
   name: 'ContactPage'
}
</script>
