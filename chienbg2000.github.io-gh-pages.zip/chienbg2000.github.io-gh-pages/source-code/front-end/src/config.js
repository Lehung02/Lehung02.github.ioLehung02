export default {
    apiUrl: 'https://script.google.com/macros/s/AKfycbxmYK947WpbboAbG0EB_KyXQk0Ix-TMmMcA_dBQ57za8_zBmkn3_eECtLUwIW0SLpRbwg/exec',
  };
  